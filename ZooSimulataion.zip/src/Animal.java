import java.util.Random;

/**
 * Animal class is an abstract class that defines common methods and fields throughout different types of animals
 **/
public abstract class Animal {
	
	private int lifeExpectancy; // stores the average age that the Animal lives to in months
	private String[] eats; // stores the types of food that the Animal can eat
	private int age; // stores the age of the Animal in months
	private char gender; // stores whether the Animal is Male (�m�) or Female (�f�)
	private int health; // stores how healthy the animal is, 10 being healthiest
	
	private Enclosure enclosure; // stores the reference to the enclosure the Animal belongs to
	private int waste; // stores the amount of waste the animal will produce
	
	protected StringBuffer detailStatus; // stores details of what the animal does
	
	public static final int MAX_health = 10; // maximum health an animal can have
	public static final int MIN_health = 0;
	public static final int startingAge = 1;
	
	public Animal(int lifeExpectancy, String[] eats, char gender, int initialAge, int initialHealth){
		this.age = initialAge;
		setHealth(initialHealth);
		this.lifeExpectancy = lifeExpectancy;
		setGender(gender);
		this.eats = eats;
		this.waste = 0;
		detailStatus = new StringBuffer();
	}
	
	public Animal(){
		this.age = startingAge;
		this.health = MAX_health;
		this.lifeExpectancy = 30;
		setGender(gender);
		this.eats = new String[] {"hay","fruit","steak","celery"};
		this.waste = 0;
		detailStatus = new StringBuffer();
	}
	
	/*
	 * The gender of the animal will be female or male
	 */
	private void setGender(char gender){
		if (gender == 'f'){
			this.gender = gender;
		} else {
			this.gender = 'm';
		}
	}
	
	/* 
	 * Checks if the animal's health reaches 0 or if it reaches it's life expectancy
	 * Animal dies if it is too old
	 */
	private boolean isDead(){
		if (health <= 0){
			return true;
		}
		if (age >= lifeExpectancy){
			return true;
		}
		return false;
	}
	
	/* 
	 * Select a random food the animal can eat and returns it
	 */
	private String getRandomFood(){
		Random rand = new Random();
		int number = rand.nextInt(eats.length);
		return this.eats[number];
	}
	
	/* 
	 * This method calls the core methods that allow the animal to eat, loose health points, excrete and grow 
	 * It also reduces the health of the animal by 2, 
	 * and if the animal is still alive it will be allowed to eat, produce waste
	 * 
	 * The returned boolean is true if the animal is still alive after the month
	 * 
	 * NOTE: The specification suggests this method to be abstract in Animal class.
	 * However, I decided to make it non-abstract as this method looks exactly the same for all Animal sub-classes.
	 * If in the future a subclass wants to implement this method differently, it will still be able to do so by overriding.
	 */
	public boolean aMonthPasses(){
		// Clears the StringBuffer, apparently this is a good way to do so
		detailStatus.setLength(0);
		
		decreaseHealth(2);
		increaseAge();
		if (isDead()){
			detailStatus.append("dies; ");
			return false;
		}
		eat();
		excrete();
		return true;
	}
	
	// Returns whether or not the Animal can eat the specified type of food 
	public boolean canEat(String food){
		boolean found = false;
		int i = 0;
		
		// loops through the array of food in variable 'eats' until the name of the food is found or reaches the end of the array
		while (( !found ) && ( i < eats.length )){
			if (eats[i].equals(food)){
				found = true;
			}
			i++;
		}
		
		return found;
	}
	
	/* 
	 * This method will make the Animal eat a random piece of food 
	 * As a result this increases the animals health and produces waste
	 */
	public boolean eat(){
		int foodCount = eats.length;
		String food = "";
		boolean eaten = false;
		while ((foodCount > 0) && (!eaten)) {
			foodCount--;
			food = eats[foodCount];
			eaten = enclosure.getFoodstore().takeFood(food);
		}
		
		if (eaten) {
			detailStatus.append("eats " + food + "; ");
			increaseHealth( Foodstore.getFoodHealth(food) );
			waste = waste + Foodstore.getFoodWaste(food);
			return true;
		} else {
			detailStatus.append("FAILS to eat; ");
			return false;
		}
	}

	public int getAge(){
		return age;
	}
	
	public char getGender(){
		return gender;
	}
	
	public String[] getEatsArray(){
		return eats;
	}
	
	public void setEnclosure(Enclosure enclosure){
		this.enclosure = enclosure;
	}
	
	public void decreaseHealth(){
		decreaseHealth(1);
	}
	
	public boolean decreaseHealth(int healthPoints){
		if (healthPoints > 0){
			detailStatus.append("looses " + healthPoints + " health points; ");
			setHealth(health - healthPoints);
			return true;
		} else {
			return false;
		}
	}
	
	public void increaseHealth(){
		increaseHealth(1);
	}
	
	// Increases health points but if healthPoints is a negative number health will not be increased
	public boolean increaseHealth(int healthPoints){
		if (healthPoints > 0){
			detailStatus.append("gains " + healthPoints + " health points; ");
			setHealth(health + healthPoints);
			return true;
		} else {
			return false;
		}
	}
	
	// Sets Health of the animal verifying that the value is within bounds
	private void setHealth(int healthPoints){
		health = healthPoints;
		if (health > MAX_health){
			health = MAX_health;
		} else if (health < MIN_health) {
			health = 0;
		}
	}
	
	private void increaseAge(){
		detailStatus.append("gets older by " + 1 + " month; ");
		age++;
	}
	
	// The Animal can be given a treat
	public abstract void treat();
	
	// Returns the amount of waste the animal will produce and empty's the waste for next time
	public void excrete(){
		enclosure.addWaste(waste);
		detailStatus.append("produces " + waste + " waste; ");
		waste = 0;
	}
	
	// Returns the status of the animal as a string
	public StringBuffer getAnimalStatus(int mode){
		return new StringBuffer(this.getClass().getName() + "("+ gender +") "
				+ ((mode == 2) ? " " + detailStatus + "\n\t\t": "")
				+ " At the end of the month has " + health + " health and is " + age + " months old");
	}
}