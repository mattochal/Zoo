import java.util.ArrayList;
import java.util.Arrays;

public class PhysioZookeeper extends Zookeeper {

	public PhysioZookeeper(Enclosure enclosure) {
		super(enclosure);
		canTreat.add(Elephant.class);
		canTreat.add(Giraffe.class);
		
	}

	public PhysioZookeeper() {
		super();
		canTreat.add(Elephant.class);
		canTreat.add(Giraffe.class);
	}
	
	public static void main(String args[]){
		try {
			System.out.println("a,".split(",").length);
			//System.out.println("a");
			for (String s : "".split(","))
				System.out.println(s);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
